document.addEventListener("DOMContentLoaded", function() {
  M.toast({ html: 'Bad news! There was an error sending your message. Please try again.',
    displayLength: 6000,
    classes: 'red darken-4' });
});
